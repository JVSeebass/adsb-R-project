
# info: latitude/Breitengrad von -90(S?d) bis +90(Nord)
# longitude/L?ngengrad von -180(West) bis 180(Ost)


####Get data####
get_live_data <- function(point="",radius = 100, country = "", type = ""){
  library("jsonlite")
  library("maps")
  library("stringr")

  # create search link for the api
  link <- paste("http://public-api.adsbexchange.com/VirtualRadar/AircraftList.json?",sep = "")

  if (point != ""){
    # convert city into point
    if(any(point == world.cities)){
      select <- which(world.cities == point)
      if(length(select) > 1){
        select <- select[which(max(world.cities[select,3])==world.cities[select,3])]
      }
      point <- as.vector(world.cities[select,4:5])
    }

    # check for necessary conditions
    if(TRUE==TRUE){
      if(length(point) != 2){
        stop("Point has to be a city or of length 2!")
      }
      if(point[1] < -90 || point[1] > 90){
        stop("Latitude has to be between -90 and 90!")
      }
      if(point[2] < -180 || point[2] > 180){
        stop("Longitude has to be between -180 and 180!")
      }
    }
    link <- paste(link,"lat=",point[1],
                  "&lng=",point[2],"&fDstL=0&fDstU=",radius,sep = "","&")
  }

  if (country != ""){
    link <- paste(link, "fCouS=", country, sep = "","&")
  }

  if (type != ""){
    link <- paste(link, "fTypS=", type, sep = "","&")
  }


  if (substring(link,str_length(link),str_length(link)) != "&"){
    warning("You did not choose any selection parameter.")
  }
  else{
    link <- substring(link,1,str_length(link)-1)
  }

  # return(link)

  data <- read_json(link)


  # check if all data selected
  if (length(data$acList) > (data$totalAc - 10)){
    warning("No selection done! If unintended, please check your function input.")
  }

  # check if no data selected
  if (length(data$acList) == 0){
    stop("No matches found! Try another input.")
  }


  #data conversion#####

  # lat
  latvec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["Lat"]]) != 0){
        z[i] <- data[["acList"]][[i]][["Lat"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  latv <- latvec(data)

  # long
  longvec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["Lat"]]) != 0){
        z[i] <- data[["acList"]][[i]][["Long"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  longv <- longvec(data)

  # type
  typevec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["Type"]]) != 0){
        z[i] <- data[["acList"]][[i]][["Type"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  typev <- typevec(data)

  # Operator
  opvec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["Op"]]) != 0){
        z[i] <- data[["acList"]][[i]][["Op"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  opv <- opvec(data)

  # Country
  couvec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["Cou"]]) != 0){
        z[i] <- data[["acList"]][[i]][["Cou"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  couv <- couvec(data)

  # From
  fromvec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["From"]]) != 0){
        z[i] <- data[["acList"]][[i]][["From"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  fromv <- fromvec(data)

  # To
  tovec <- function(data){
    z <- rep(NA,length(data$acList))
    for (i in 1:length(data$acList)){
      if (length(data[["acList"]][[i]][["To"]]) != 0){
        z[i] <- data[["acList"]][[i]][["To"]]
      }
    }
    z <- unlist(z)
    return(z)
  }
  tov <- tovec(data)

  # dframe
  dframe <- data.frame(Lat = latv, Long = longv, Op = opv, Type = typev, Cou = couv,
                       From = fromv, To = tov)

  # return #####
  return(dframe)
  #return(link)
}


dat3 <- get_live_data(type = "A320")

dat4 <- get_live_data(point = "Gottingen")

dat<- read_json("https://public-api.adsbexchange.com/VirtualRadar/AircraftList.json?lat=50
                  &lng=-13&fDstL=0&fDstU=100")


####Utility####

##########
#n_planes#
##########

# n_planes returns the number of planes in a selected area.

n_planes <- function(point="",radius=100,country = ""){
  data <- get_live_data(point,radius,country)
  z <- length(data[,1])
  cat("There are currently ", z, " airplanes flying ",radius," km around ",point,".",sep = "")
}

n_planes("Gottingen",100)

# bei Stadtnamen ? durch o ersetzen.

#############
#plot_planes#
#############

# plot_planes shows the location of the planes on a map
# klick on the makers to get further information

plot_planes <- function(point="",radius=100,country="",type = "", live = TRUE){

  # choose type of data
  if (live == TRUE){
    data <- get_live_data(point,radius,country,type)
  }
  else{
    data <- get_historic(...)
  }


  library(leaflet)

  # popup information
  info <- c()
  for (i in 1:length(data$acList)){
    info <- c(info,paste("<b>From: </b>", data$From,"<br/>",
                         "<b>To: </b>", data$To,"<br/>",
                         "<b>Operator: </b>",data$Op,"<br/>",
                         "<b>Type: </b>",data$Type,
                         sep = ""))
  }

  # create a map
  map <- leaflet() %>% addTiles()

  # plot a marker for every airplane with additional information
  map %>% addMarkers(data$Long,data$Lat,
                     popup = info)
}

plot_planes(point = "Gottingen")




# plot the flight route of one airplane

plot_airways <- function(point="",radius=100,country="", live = TRUE){

  if (live == TRUE){
    data <- get_live_data(point,radius,country)
  }
  else{
    data <- get_historic(...)
  }

  library(leaflet)

  map <- leaflet() %>% addTiles()

  map %>% addPolylines(data$Long, data$Lat)
}

plot_airways("Gottingen")


