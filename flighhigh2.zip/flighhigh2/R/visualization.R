#' n_planes
#'
#' @description This function returns the number of aircrafts in a selected area.
#'
#' @param point A vector containing latitude and longitude of a specific point or
#' a string containing the name of a city.
#'
#' @param radius The number of kilometers which should be considered as radius
#'for a circular area around the point.
#'
#' @return A sentence which defines the area and the number of aircrafts in it.
#' "There are currently \emph{x} airplanes in the area \emph{y} km around \emph{city}."
#'
#' @examples n_planes("New York")
#' n_planes("Copenhagen", radius = 200)
#'
#' @details See also \code{\link{get_live_data}}



n_planes <- function(point="",radius=100){
  data <- get_live_data(point,radius)
  z <- length(data[,1])
  cat("There are currently ", z, " airplanes in the area ",radius," km around ",point,".",sep = "")
}





#' plot_planes
#'
#' @description Creates an interactive map with markers at the current position of aircrafts.
#' Clicking on the marker will provide further information about the aircraft.
#'
#'@param point A vector containing latitude and longitude of a specific point or
#'a string containing the name of a city to determine a specicfic position as inital point.
#'
#'@param radius The number of kilometers which should be considered as radius
#'for a circular selection area around the point.
#'
#'@param country A string containing the country where an aircraft is registred.
#'
#'@param type A string containing a specific aircraft type.
#'
#'@param live Boolean wether to choose live data or historic data.
#'
#'@examples plot_planes("London",50)
#' plot_planes(country = "Algeria")
#' plot_planes(type = "A319")
#'
#' @details For further examples see \code{\link{get_live_data}}
#'
#' @return An interactive worldmap on which the position of the aircrafts is displayed.
#'



plot_planes <- function(point="",radius=100,country="",type = "", live = TRUE){

  # choose type of data
  if (live == TRUE){
    data <- get_live_data(point,radius,country,type)
  }
  else{
    data <- get_historic(...)
  }

  # popup information
  info <- c()
  for (i in 1:length(data$acList)){
    info <- c(info,paste("<b>From: </b>", data$From,"<br/>",
                         "<b>To: </b>", data$To,"<br/>",
                         "<b>Operator: </b>",data$Op,"<br/>",
                         "<b>Type: </b>",data$Type,
                         sep = ""))
  }

  # create a map
  map <- leaflet::leaflet() %>% leaflet::addTiles()

  # plot a marker for every airplane with additional information
  map %>% leaflet::addMarkers(data$Long,data$Lat,
                     popup = info)
}




#'plot_airways
#'
#'@description A function which plots the flightroute of an aircraft. Only recommended for historical data.
#'
#'@param point A vector containing latitude and longitude of a specific point or
#'a string containing the name of a city to determine a specicfic position as inital point.
#'
#'@param radius The number of kilometers which should be considered as radius
#'for a circular selection area around the point
#'
#'@param country A string containing the country where an aircraft is registred
#'
#'@param type A string containing a specific aircraft type
#'
#'@param live Boolean wether to choose live data or historic data.
#'


plot_airways <- function(point="",radius=100,country="", live = TRUE){

  if (live == TRUE){
    data <- get_live_data(point,radius,country)
  }
  else{
    data <- get_historic(...)
  }

  library(leaflet)

  map <- leaflet() %>% addTiles()

  map %>% addPolylines(data$Long, data$Lat)
}
